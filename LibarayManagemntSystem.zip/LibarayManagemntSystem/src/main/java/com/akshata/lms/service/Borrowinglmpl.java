package com.akshata.lms.service;

import java.util.Date;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akshata.lms.entities.Book;
import com.akshata.lms.entities.Borrowing;
import com.akshata.lms.entities.Member;
import com.akshata.lms.repo.BookRepo;
import com.akshata.lms.repo.BorrowingRepo;
import com.akshata.lms.repo.MemberRepo;

public class Borrowinglmpl  implements BorrowingService{
	@Autowired
	BookRepo b;
	@Autowired
	BorrowingRepo br;
	@Autowired
	MemberRepo m;

	@Override
	public Borrowing borrowBook(long bookId, long memberId) {
		Book book = b.findById(bookId).get();
		Member byId = m.findById(memberId).get();
		Borrowing b1 = new Borrowing();
		b1.setBook(book);
		b1.setBorrowedDate(new Date());
		b1.setMember(byId);
		return br.save(b1);
	}

	@Override
	public Borrowing returnBook(long borrowId) {
		Borrowing borrowing = br.findById(borrowId).get();
		borrowing.setReturnDate(new Date());
		return br.save(borrowing);
	}


}
