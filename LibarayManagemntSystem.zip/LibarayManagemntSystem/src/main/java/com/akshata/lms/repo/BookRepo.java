package com.akshata.lms.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akshata.lms.entities.Book;

public interface BookRepo extends JpaRepository<Book, Long> {
	List<Book> findByTitle(String title);

}
