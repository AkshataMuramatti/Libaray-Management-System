package com.akshata.lms.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akshata.lms.entities.Borrowing;

public interface BorrowingRepo extends JpaRepository<Borrowing, Long> {

}
