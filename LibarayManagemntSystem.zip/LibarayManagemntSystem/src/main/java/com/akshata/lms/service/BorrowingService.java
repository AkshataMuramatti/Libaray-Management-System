package com.akshata.lms.service;

import com.akshata.lms.entities.Borrowing;

public interface BorrowingService {
	Borrowing borrowBook(long borrowId, long memberId);

	Borrowing returnBook(long borrowId);

}
