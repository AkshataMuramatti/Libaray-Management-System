package com.akshata.LibarayManagemntSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibarayManagemntSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibarayManagemntSystemApplication.class, args);
	}

}
