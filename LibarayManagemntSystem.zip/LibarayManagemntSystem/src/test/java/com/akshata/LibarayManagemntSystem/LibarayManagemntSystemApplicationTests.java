package com.akshata.LibarayManagemntSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibarayManagemntSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
